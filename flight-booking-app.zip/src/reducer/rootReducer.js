import { combineReducers } from 'redux';
import flightDetailsReducer from './flightDetailsReducer'

export default combineReducers({
    flightDetailsReducer
})